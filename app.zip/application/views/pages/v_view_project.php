<section class="panel">
    <header class="panel-heading">
        <div class="panel-actions">
            <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a> 
        </div>
        <h2 class="panel-title">View Project</h2>
    </header>
	<div class="panel-body">
	    <form id="demo-form" class="form-horizontal mb-lg" novalidate="novalidate"> 	
			<?php
			  if(isset($core_project)){
			  foreach($core_project as $cp){
			?> 
	        <input type="text" name="kd_project" class="form-control" value="<?php echo $cp->kd_project;?>" readonly="readonly"/>
	        <div class="form-group mt-lg">
	            <label class="col-sm-4 control-label">Project Name</label>
	            <div class="col-sm-6">
	                <input type="text" name="projectname" class="form-control" value="<?php echo $cp->projectname; ?>" readonly="readonly"/>
	            </div>
	        </div> 
			<?php }
			}
			?> 

			<?php
			  if(isset($projecthistory)){
			  foreach($projecthistory as $ph){
			?> 
			<div class="form-group mt-lg">
	            <label class="col-sm-4 control-label">PIC QT</label>
	            <div class="col-sm-6">
	                <input type="text" name="id_qtname" class="form-control" value="<?php echo $ph->qtname; ?>" readonly="readonly"/>
	            </div>
	        </div>
	           
			<div class="form-group mt-lg">
	            <label class="col-sm-4 control-label">PIC PMO</label>
	            <div class="col-sm-6"> 
	                <input type="text" name="id_qtname" class="form-control" value="<?php echo $ph->pmoname; ?>" readonly="readonly"/>
	            </div>
	        </div>	
 
			<div class="form-group mt-lg">
                <label class="col-sm-4 control-label">Start Date</label>
                <div class="col-md-6">
					 <div class="form-group"> 
						<div class="col-md-6">
							<div class="input-group">
								<span class="input-group-addon">
									<i class="fa fa-calendar"></i>
								</span>
								<input type="text" data-plugin-datepicker class="form-control" id="st_awal" name="st_awal" value="<?php echo $ph->st_awal; ?>">
							</div>
						</div>
					</div>
				</div>
            </div>	

			<div class="form-group mt-lg">
                <label class="col-sm-4 control-label">End Date</label>
                <div class="col-md-6">
					 <div class="form-group"> 
						<div class="col-md-6">
							<div class="input-group">
								<span class="input-group-addon">
									<i class="fa fa-calendar"></i>
								</span>
								<input type="text" data-plugin-datepicker class="form-control" id="st_akhir" name="st_akhir" value="<?php echo $ph->st_akhir; ?>">
							</div>
						</div>
					</div>
				</div>
            </div>				
 
			<?php }
			}
			?> 
			
			 <?php
			  if(isset($projectallhistorydescription)){
			  $no=1; foreach($projectallhistorydescription as $pahd){
			 ?>
				<div class="col-md-12">
					<div class="panel-group" id="accordion">
						<div class="panel panel-accordion">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#<?php echo $pahd->id_history; ?>">
										History tanggal <?php echo date("d M Y",strtotime($pahd->create_date)); ?> by <?php echo $pahd->creator; ?>
									</a>
								</h4>
							</div>
							<div id="<?php echo $pahd->id_history; ?>" class="accordion-body collapse">
								<div class="panel-body">
									
					<section class="panel">

						<div class="panel-body">
							<form class="form-horizontal form-bordered form-bordered" action="#">  
								<div class="form-group"> 
									<label class="col-md-3 control-label" for="textareaDefault">Description</label>
									<div class="col-md-6">
										<textarea class="form-control" readonly="readonly"><?php echo $pahd->description; ?></textarea>
									</div>
								</div>  
								<div class="form-group">
									<label class="col-md-3 control-label" for="textareaDefault">Project Status</label>
									<div class="col-md-6">
										<input type="text" name="status_project" class="form-control" value="<?php echo $pahd->status_project; ?>" readonly="readonly"/>
									</div>
								</div>
							</form>
						</div>
					</section> 
								</div>
							</div>
						</div>
					</div>
				</div>
			
			<?php $no++; }
			}
			?>  
			  

	    </form> 
	</div>
</section> 


