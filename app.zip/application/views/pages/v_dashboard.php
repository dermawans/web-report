
<!--========================= Content Wrapper ==============================-->
<!-- start: page -->
<div class="row">
    <section class="panel panel-dark">
        <header class="panel-heading">
            <div class="panel-actions">
                <a href="#" class="panel-action panel-action-toggle" data-panel-toggle></a> 
            </div>

            <h2 class="panel-title">Dashboard</h2>
        </header>
        <div class="panel-body">
            <code>Selamat Datang <?php echo $this->session->userdata('USERNAME'); ?></code>
        </div>
    </section>
</div>
                    
<!-- end: page -->




